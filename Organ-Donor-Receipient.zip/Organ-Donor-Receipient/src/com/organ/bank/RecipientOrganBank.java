package com.organ.bank;

/*
 * One of the Refined abstraction for Abstraction -WHO.java 
 */

import com.organ.supervisory.OrganBank;
import com.organ.supervisory.WHO;

public class RecipientOrganBank extends WHO {
	public RecipientOrganBank(OrganBank organBank)
	{
		super(organBank);
	}

	@Override
	public void getConfirmation()
	{
		System.out.print("User registered with OrganBank as a ");
		organBank.message();
	}
}