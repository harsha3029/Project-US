package com.organ.supervisory;

/*
 * Bridge pattern implemented to display user -a confirmation message- post his submission of input.
 * This class WHO is the Abstraction under which there can be Donor and Recipient Organ banks (Refined abstraction).
 */

public abstract class WHO {
	protected OrganBank organBank;

	protected WHO(OrganBank organBank)
	{
		this.organBank = organBank;
	
	}

	abstract public void getConfirmation();
}
