package com.organ.supervisory;
/*
 * This OrganBank is the Implementor in the BridgePattern
 * This has a method that is implemented by concrete implementation i.e DonorBuilder and RecipientBuilder to send custom message as per Applicant type.
 */
public interface OrganBank
{
	abstract public void message();
}