package com.organ.user.details;

/*
 * Implemented using Builder Pattern with build method at line number 22
 * 
 * Implemented Singleton Design Pattern (Singleton class is User.java always returns only one object) at line number 23
 * 
 */

public abstract class UserBuilder {

	protected String firstName;
	protected String lastName;
	protected String phoneNumber;
	protected String organType;
	protected String emailId;
	protected String address;

	public abstract UserBuilder submitDetails(String firstName, String lastName, String phoneNumber, String organType,
			String emailId, String address);

	public User build() {
		// Singleton Design Pattern implementation always single user instance is retrieved.
		User user = User.getInstance();
		user.setFirstName(this.firstName);
		user.setLastName(this.lastName);
		user.setPhoneNumber(this.phoneNumber);
		user.setOrganType(this.organType);
		user.setEmailId(this.emailId);
		user.setAddress(this.address);
		return user;
	}

}
