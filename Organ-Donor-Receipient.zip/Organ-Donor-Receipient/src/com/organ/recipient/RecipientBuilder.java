package com.organ.recipient;

/*
 * This is one of the leaf class that inherits the common behavior of Component Applicants.java and Composite class TotalApplicants.java
 * Builder pattern is referenced in this file at line 37
 * Bridge Pattern concrete implementation at Line 51
 */ 

import com.organ.applicants.Applicants;
import com.organ.supervisory.OrganBank;
import com.organ.user.details.UserBuilder;

public class RecipientBuilder extends UserBuilder implements Applicants,OrganBank {

	private String firstName;
	private String phoneNumber;
	private String organType;

	public RecipientBuilder() {

	}

	public RecipientBuilder(String firstName, String lastName, String phoneNumber, String organType, String emailId,
			String address) {
		this.firstName = firstName;
		this.phoneNumber = phoneNumber;
		this.organType = organType;
	}


	@Override
	public void getApplicants() {
	System.out.println("Recipient  "+this.firstName+ " , "+this.phoneNumber+ " is willing to receive organ : "+ this.organType);
	}



	@Override
	public UserBuilder submitDetails(String firstName, String lastName, String phoneNumber, String organType,
			String emailId, String address) {
		super.firstName = firstName;
		super.lastName = lastName;
		super.phoneNumber = phoneNumber;
		super.organType = organType;
		super.emailId = emailId;
		super.address = address;
		return this;
	}
	
	@Override
	public void message()
	{
		System.out.print(" RECIPIENT " );
	}

}
