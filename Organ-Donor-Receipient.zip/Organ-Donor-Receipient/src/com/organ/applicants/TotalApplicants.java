package com.organ.applicants;

/*
 * This is the Composite class that stores child components -leaves (DonorBuider and RecipientBuilder)  
 * 
 */

import java.util.ArrayList;
import java.util.List;

public class TotalApplicants implements Applicants {

	private List<Applicants> applicantsList=new ArrayList<Applicants>();
	
	@Override
	public void getApplicants() {

		for(Applicants applicant : applicantsList)
		{
			applicant.getApplicants();
		}
		
	}
	
	public void addDonors(Applicants donor)
	{
		applicantsList.add(donor);
	}
	
	public void addRecipients(Applicants recipients)
	{
		applicantsList.add(recipients);
	}

}
