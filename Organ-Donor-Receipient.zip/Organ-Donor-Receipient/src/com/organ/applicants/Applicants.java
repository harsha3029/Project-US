package com.organ.applicants;

/*
 * This is the Component Interface for implementing Composite Pattern- contains default behavior common to classes implementing it
 * 
 */

public interface Applicants {

	public void getApplicants();
}
